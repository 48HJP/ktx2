const express = require('express');
const router = express.Router();
const Book = require('../models/Book');

// GET /api/books — Lấy danh sách tất cả các cuốn sách có trong database
// Logic: Dùng Book.find() để truy vấn toàn bộ documents trong collection "books"
// Trả về mảng JSON chứa tất cả sách, status 200 nếu thành công
router.get('/', async (req, res) => {
  try {
    const books = await Book.find();
    res.status(200).json(books);
  } catch (error) {
    res.status(500).json({ message: 'Lỗi server', error: error.message });
  }
});

// POST /api/books — Thêm mới một cuốn sách
// Logic: Nhận title, author, price từ req.body
// Tạo instance mới của model Book, gọi .save() để lưu vào MongoDB
// Trả về thông tin sách vừa được tạo với status 201
router.post('/', async (req, res) => {
  try {
    const { title, author, price } = req.body;

    const newBook = new Book({
      title,
      author,
      price
    });

    const savedBook = await newBook.save();
    res.status(201).json(savedBook);
  } catch (error) {
    if (error.name === 'ValidationError') {
      return res.status(400).json({ message: 'Dữ liệu không hợp lệ', error: error.message });
    }
    res.status(500).json({ message: 'Lỗi server', error: error.message });
  }
});

module.exports = router;
