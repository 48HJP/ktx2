const express = require('express');
const router = express.Router();
const Note = require('../models/Note');

// GET /api/notes - Lấy toàn bộ ghi chú, sắp xếp theo thời gian tạo mới nhất lên đầu
router.get('/', async (req, res) => {
  try {
    const notes = await Note.find().sort({ createdAt: -1 });
    res.status(200).json(notes);
  } catch (error) {
    res.status(500).json({ message: 'Lỗi server', error: error.message });
  }
});

// POST /api/notes - Tạo ghi chú mới
router.post('/', async (req, res) => {
  try {
    const { title, content, isPinned } = req.body;

    const newNote = new Note({
      title,
      content,
      isPinned
    });

    const savedNote = await newNote.save();
    res.status(201).json(savedNote);
  } catch (error) {
    if (error.name === 'ValidationError') {
      return res.status(400).json({ message: 'Dữ liệu không hợp lệ', error: error.message });
    }
    res.status(500).json({ message: 'Lỗi server', error: error.message });
  }
});

module.exports = router;
