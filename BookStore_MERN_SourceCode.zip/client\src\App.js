import React, { useState, useEffect } from 'react';
import './App.css';

function BookStoreApp() {
  // State lưu danh sách sách từ database
  const [books, setBooks] = useState([]);
  // State cho các trường input của form thêm sách
  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('');
  const [price, setPrice] = useState('');
  // State quản lý trạng thái loading, submitting, error
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState('');

  const API_URL = '/api/books';

  // useEffect: Gọi API GET /api/books khi component mount lần đầu
  // Logic: fetch() gửi GET request tới backend → nhận mảng JSON sách → setBooks()
  useEffect(() => {
    const controller = new AbortController();

    const fetchBooks = async () => {
      try {
        setLoading(true);
        setError(null);
        const response = await fetch(API_URL, { signal: controller.signal });

        if (!response.ok) {
          throw new Error(`Lỗi tải dữ liệu (${response.status})`);
        }

        const data = await response.json();
        setBooks(data);
      } catch (err) {
        if (err.name !== 'AbortError') {
          console.error('Lỗi khi lấy danh sách sách:', err);
          setError(err.message || 'Không thể tải danh sách sách từ server');
        }
      } finally {
        setLoading(false);
      }
    };

    fetchBooks();

    return () => controller.abort();
  }, []);

  // handleSubmit: Gọi API POST /api/books khi bấm "Thêm sách"
  // Logic: fetch() gửi POST request với body JSON { title, author, price }
  // → Backend tạo document mới trong MongoDB → trả về sách vừa tạo
  // → Cập nhật state books bằng cách thêm sách mới vào đầu mảng (không cần reload trang)
  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!title.trim() || !author.trim() || !price) {
      setError('Vui lòng nhập đầy đủ thông tin sách!');
      return;
    }

    try {
      setSubmitting(true);
      setError(null);
      setSuccess('');

      const response = await fetch(API_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          title: title.trim(),
          author: author.trim(),
          price: Number(price)
        })
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.message || 'Lỗi khi thêm sách');
      }

      const newBook = await response.json();

      // Cập nhật danh sách sách ngay lập tức — thêm vào đầu mảng
      setBooks((prevBooks) => [newBook, ...prevBooks]);

      // Reset form về rỗng
      setTitle('');
      setAuthor('');
      setPrice('');
      setSuccess(`Đã thêm sách "${newBook.title}" thành công!`);

      // Tự ẩn thông báo sau 3 giây
      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      console.error('Lỗi khi thêm sách:', err);
      setError(err.message || 'Có lỗi xảy ra khi thêm sách');
    } finally {
      setSubmitting(false);
    }
  };

  // Format giá tiền theo VND
  const formatPrice = (price) => {
    return new Intl.NumberFormat('vi-VN').format(price) + 'đ';
  };

  return (
    <div className="app-wrapper">
      {/* Header */}
      <header className="app-header">
        <div className="header-content">
          <h1 className="app-title">
            <span className="title-icon">🦅</span>
            LIBRARIUM IMPERIALIS
            <span className="title-badge">WARHAMMER 40K</span>
          </h1>
          <p className="app-subtitle">
            ⚔️ "IN THE GRIM DARKNESS OF THE FAR FUTURE, THERE IS ONLY KNOWLEDGE" • MERN STACK ARCHIVE ⚔️
          </p>
        </div>
      </header>

      <main className="main-content">
        {/* Form thêm sách */}
        <section className="form-section">
          <div className="section-header">
            <h2 className="section-title">
              <span className="section-icon">📜</span>
              Khắc Ghi Thánh Thư Mới (Inscribe Tome)
            </h2>
          </div>

          <form className="book-form" onSubmit={handleSubmit}>
            <div className="form-group">
              <label className="form-label" htmlFor="book-title">
                📖 Tiêu Đề Thánh Thư (Tome Title)
              </label>
              <input
                id="book-title"
                type="text"
                className="form-input"
                placeholder="Nhập danh xưng cổ thư (vd: Codex Astartes, Sapiens...)"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label" htmlFor="book-author">
                ✍️ Thư Lại / Tác Giả (Scribe / Author)
              </label>
              <input
                id="book-author"
                type="text"
                className="form-input"
                placeholder="Nhập tên thư lại (vd: Roboute Guilliman, Tony...)"
                value={author}
                onChange={(e) => setAuthor(e.target.value)}
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label" htmlFor="book-price">
                🪙 Giá Trị Tín Chỉ (Imperial Credits - VNĐ)
              </label>
              <input
                id="book-price"
                type="number"
                className="form-input"
                placeholder="Nhập giá tín chỉ..."
                value={price}
                onChange={(e) => setPrice(e.target.value)}
                min="0"
                required
              />
            </div>

            <button
              type="submit"
              className="submit-btn"
              disabled={submitting || !title.trim() || !author.trim() || !price}
            >
              {submitting ? (
                <span>⏳ Đang niêm ấn...</span>
              ) : (
                <>
                  <span>⚡</span>
                  <span>Khắc Ghi Vào Librarium</span>
                </>
              )}
            </button>
          </form>

          {/* Thông báo lỗi */}
          {error && (
            <div className="alert alert-error">
              ☠️ [DỊ GIÁO / LỖI]: {error}
            </div>
          )}

          {/* Thông báo thành công */}
          {success && (
            <div className="alert alert-success">
              ⚜️ [THÀNH TỰU]: {success}
            </div>
          )}
        </section>

        {/* Danh sách sách */}
        <section className="list-section">
          <div className="section-header">
            <h2 className="section-title">
              <span className="section-icon">💀</span>
              Biên Niên Cổ Thư (Codex Registry)
            </h2>
            <span className="book-count">{books.length} Thánh Thư</span>
          </div>

          <div className="books-container">
            {loading ? (
              <div className="loading-state">
                <div className="loading-spinner"></div>
                <p>Đang giải mã văn khế cổ từ MongoDB Cogitator...</p>
              </div>
            ) : books.length === 0 ? (
              <div className="empty-state">
                <div className="empty-icon">⚔️</div>
                <p className="empty-title">Librarium Hiện Đang Trống!</p>
                <p className="empty-subtitle">Hãy khắc ghi bộ thánh thư đầu tiên bằng nghi thức bên trên.</p>
              </div>
            ) : (
              <div className="books-table-wrapper">
                <table className="books-table">
                  <thead>
                    <tr>
                      <th className="th-stt">#</th>
                      <th className="th-title">Tiêu Đề Thánh Thư</th>
                      <th className="th-author">Thư Lại / Tác Giả</th>
                      <th className="th-price">Tín Chỉ (Giá)</th>
                      <th className="th-status">Niêm Ấn</th>
                    </tr>
                  </thead>
                  <tbody>
                    {books.map((book, index) => (
                      <tr key={book._id || index} className="book-row">
                        <td className="td-stt">{index + 1}</td>
                        <td className="td-title">{book.title}</td>
                        <td className="td-author">{book.author}</td>
                        <td className="td-price">{formatPrice(book.price)}</td>
                        <td className="td-status">
                          <span className={`status-badge ${book.isPublished ? 'published' : 'draft'}`}>
                            {book.isPublished ? '🛡️ Đã Niêm Ấn' : '📜 Dự Thảo'}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>

          {/* Hiển thị dạng card (Codex Relics) */}
          {!loading && books.length > 0 && (
            <div className="cards-grid">
              {books.map((book, index) => (
                <div key={book._id || index} className="book-card">
                  <div className="card-header">
                    <span className="card-number">RELIC #{index + 1}</span>
                    <span className={`card-badge ${book.isPublished ? 'published' : 'draft'}`}>
                      {book.isPublished ? '🛡️ Sanctified' : '📜 Draft'}
                    </span>
                  </div>
                  <h3 className="card-title">{book.title}</h3>
                  <p className="card-author">🖋️ Scribe: {book.author}</p>
                  <p className="card-price">{formatPrice(book.price)}</p>
                </div>
              ))}
            </div>
          )}
        </section>
      </main>

      {/* Footer */}
      <footer className="app-footer">
        <p>⚔️ FOR THE EMPEROR • BÀI KIỂM TRA THỰC HÀNH MERN STACK • LIBRARIUM ARCHIVES ⚔️</p>
      </footer>
    </div>
  );
}

export default BookStoreApp;
