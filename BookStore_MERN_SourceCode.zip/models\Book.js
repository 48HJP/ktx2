const mongoose = require('mongoose');

// Định nghĩa Schema cho collection "books" trong MongoDB
// Mỗi document đại diện cho 1 cuốn sách với các trường: title, author, price, isPublished
const bookSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'Tên sách là trường bắt buộc']
  },
  author: {
    type: String,
    required: [true, 'Tên tác giả là trường bắt buộc']
  },
  price: {
    type: Number,
    required: [true, 'Giá sách là trường bắt buộc'],
    min: [0, 'Giá sách không được nhỏ hơn 0']
  },
  isPublished: {
    type: Boolean,
    default: true
  }
});

// Xuất model "Book" — Mongoose sẽ tự tạo collection "books" trong DB
module.exports = mongoose.model('Book', bookSchema);
